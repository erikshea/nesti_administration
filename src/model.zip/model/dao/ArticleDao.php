<?php

class ArticleDao extends BaseDao{
}