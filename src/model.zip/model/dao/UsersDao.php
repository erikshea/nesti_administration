<?php

class UsersDao extends BaseDao{
 
}