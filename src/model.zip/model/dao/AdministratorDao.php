<?php
class AdministratorDao extends UserDao{
  
}