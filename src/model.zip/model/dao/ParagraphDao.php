<?php

class ParagraphDao extends BaseDao{
 
}