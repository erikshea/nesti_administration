<?php

class IngredientDao extends ProductDao{
    
}