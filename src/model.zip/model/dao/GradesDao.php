<?php

class GradesDao extends BaseDao{
 
}