<?php

class RecipesDao extends BaseDao{
 
}