<?php

class OrdersDao extends BaseDao{
 
}