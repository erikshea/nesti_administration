<?php

class ImportationDao extends BaseDao{
 
}