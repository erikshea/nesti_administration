<?php

class ImageDao extends BaseDao{
 
}