<?php

class UnitDao extends BaseDao{
 
}