<?php

class OrderLineDao extends BaseDao{
 
}