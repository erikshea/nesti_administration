<?php

class ArticlePriceDao extends BaseDao{
 
}