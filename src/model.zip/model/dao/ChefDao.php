<?php
class ChefDao extends UserDao{
  
}