<?php

class ProductDao extends BaseDao{
 
}