<?php

class LotDao extends BaseDao{
 
}