<?php
class ModeratorDao extends UserDao{
  
}