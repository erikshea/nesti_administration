<?php

class CommentDao extends BaseDao{
 
}