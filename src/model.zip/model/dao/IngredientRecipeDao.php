<?php

class IngredientRecipeDao extends BaseDao{
 
}