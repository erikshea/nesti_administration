<?php

class ConnectionLogDao extends BaseDao{
 
}